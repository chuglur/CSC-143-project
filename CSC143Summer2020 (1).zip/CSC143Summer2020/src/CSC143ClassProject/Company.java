package CSC143ClassProject;

public class Company {
	private String name;
	private int size; // number of employees?
	
	// Constructors
	public Company() {
		
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}

}
