package CSC143ClassProject;

public class SampleDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person newPerson = new Person("Aron");
		
		// Since we don't have many methods to choose from yet:
		System.out.println(newPerson.toString());
		

	}

}
