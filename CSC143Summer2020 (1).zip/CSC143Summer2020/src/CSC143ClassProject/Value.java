package CSC143ClassProject;

// The NewGrad and the Companies could have values
// that might or might not be good fits.
public class Value {

}
