package CSC143ClassProject;

// Might this be better as an interface?
public class Activity {

}
